package edu.ucalgary.oop;



public interface FormattedOutput {
	public abstract String getFormatted();
}

